  class ConstantVar{

  static int indexCont = 0;
}